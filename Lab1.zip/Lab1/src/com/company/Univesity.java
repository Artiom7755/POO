package com.company;

import java.util.ArrayList;

public class Univesity {
    public String name;
    public int found_year;
    public ArrayList<Student> students;
    public Univesity(){
        students = new ArrayList<Student>();
    }
}
