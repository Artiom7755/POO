package com.company;

public class Student {
    public String name;
    public int age;
    public float mark;
}
